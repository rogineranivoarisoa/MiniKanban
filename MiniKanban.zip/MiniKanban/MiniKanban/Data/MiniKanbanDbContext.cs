﻿using Microsoft.EntityFrameworkCore;
using MiniKanban.Models;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace MiniKanban.Data
{
    public class MiniKanbanDbContext : DbContext
    {
        public MiniKanbanDbContext(DbContextOptions<MiniKanbanDbContext> options) : base(options) { }

        public DbSet<User> Users { get; set; }
        public DbSet<Models.KanbanTask> Tasks { get; set; }
        public DbSet<TaskHistory> TaskHistories { get; set; }
    }
}
