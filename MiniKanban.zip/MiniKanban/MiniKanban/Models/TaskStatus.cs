﻿namespace MiniKanban.Models
{
    public enum TaskStatus
    {
        ToDo,
        InProgress,
        Done
    }
}