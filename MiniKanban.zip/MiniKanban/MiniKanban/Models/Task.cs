﻿using System;
using System.Collections.Generic;

namespace MiniKanban.Models
{
    public class Task
    {
        public int Id { get; set; }
        public string Title { get; set; } = null!;
        public string? Description { get; set; }
        public TaskStatus Status { get; set; } = TaskStatus.ToDo;
        public int? AssignedToUserId { get; set; }
        public User? AssignedToUser { get; set; }
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
        public ICollection<TaskHistory> History { get; set; } = new List<TaskHistory>();
    }
}
