﻿using Microsoft.AspNetCore.Mvc;
using MiniKanban.Services;
using MiniKanban.Models;

namespace MiniKanban.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class UsersController : ControllerBase
    {
        [HttpGet]
        public ActionResult<IEnumerable<User>> GetAllUsers()
        {
            return Ok(InMemoryDataService.Users);
        }
    }
}
