﻿using Microsoft.AspNetCore.Mvc;
using MiniKanban.Models;
using MiniKanban.Services;
using TaskModel = MiniKanban.Models.Task;
using TaskStatusModel = MiniKanban.Models.TaskStatus;

namespace MiniKanban.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TasksController : ControllerBase
    {
        // GET /api/tasks
        [HttpGet]
        public ActionResult<IEnumerable<TaskModel>> GetAllTasks()
        {
            return Ok(InMemoryDataService.Tasks);
        }

        // GET /api/tasks/{id}
        [HttpGet("{id}")]
        public ActionResult<TaskModel> GetTaskById(int id)
        {
            var task = InMemoryDataService.Tasks.FirstOrDefault(t => t.Id == id);
            if (task == null) return NotFound();

            var history = InMemoryDataService.GetHistoryForTask(id);
            task.History = history;

            return Ok(task);
        }

        // POST /api/tasks
        [HttpPost]
        public ActionResult<TaskModel> CreateTask([FromBody] CreateTaskDto dto)
        {
            if (dto == null || string.IsNullOrWhiteSpace(dto.Title))
                return BadRequest("Title is required");

            var createdTask = InMemoryDataService.CreateTask(dto.Title, dto.Description, dto.AssignedToUserId, dto.CreatedByUserId);
            return CreatedAtAction(nameof(GetTaskById), new { id = createdTask.Id }, createdTask);
        }

        // PUT /api/tasks/{id}/status
        [HttpPut("{id}/status")]
        public IActionResult UpdateStatus(int id, [FromBody] UpdateStatusDto dto)
        {
            if (!Enum.IsDefined(typeof(TaskStatusModel), dto.NewStatus))
                return BadRequest("Invalid status value");

            if (!InMemoryDataService.UpdateStatus(id, dto.NewStatus, dto.ChangedByUserId, out var error))
                return BadRequest(error);

            return NoContent();
        }

        // PUT /api/tasks/{id}/assign
        [HttpPut("{id}/assign")]
        public IActionResult AssignTask(int id, [FromBody] AssignTaskDto dto)
        {
            if (!InMemoryDataService.AssignTask(id, dto.AssignedToUserId, dto.ChangedByUserId, out var error))
                return BadRequest(error);

            return NoContent();
        }
    }

    // DTOs
    public class CreateTaskDto
    {
        public string Title { get; set; } = null!;
        public string? Description { get; set; }
        public int? AssignedToUserId { get; set; }
        public int CreatedByUserId { get; set; }
    }

    public class UpdateStatusDto
    {
        public TaskStatusModel NewStatus { get; set; }
        public int ChangedByUserId { get; set; }
    }

    public class AssignTaskDto
    {
        public int? AssignedToUserId { get; set; }
        public int ChangedByUserId { get; set; }
    }
}
