﻿using System;
using System.Collections.Generic;
using System.Linq;
using MiniKanban.Models;
using TaskModel = MiniKanban.Models.Task;
using TaskStatusModel = MiniKanban.Models.TaskStatus;


namespace MiniKanban.Services
{
    public static class InMemoryDataService
    {
        // Simule des Users
        public static List<User> Users { get; } = new List<User>()
        {
            new User { Id = 1, UserName = "Alice" },
            new User { Id = 2, UserName = "Bob" }
        };

        // Simule les Tasks
        public static List<TaskModel> Tasks { get; } = new List<TaskModel>();

        // Simule l'historique
        public static List<TaskHistory> TaskHistories { get; } = new List<TaskHistory>();

        private static int _nextTaskId = 1;
        private static int _nextHistoryId = 1;

        // ✅ Créer une tâche
        public static TaskModel CreateTask(string title, string? description, int? assignedToUserId, int createdByUserId)
        {
            var task = new TaskModel
            {
                Id = _nextTaskId++,
                Title = title,
                Description = description,
                Status = TaskStatus.ToDo,
                AssignedToUserId = assignedToUserId,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            };
            Tasks.Add(task);

            AddHistory(task.Id, createdByUserId, "Creation", null, $"Task created with status {task.Status}");

            return task;
        }

        // ✅ Mettre à jour le statut
        public static bool UpdateStatus(int taskId, TaskStatus newStatus, int changedByUserId, out string? error)
        {
            error = null;
            var task = Tasks.FirstOrDefault(t => t.Id == taskId);
            if (task == null)
            {
                error = "Task not found.";
                return false;
            }

            // Validation des transitions
            if (!IsValidTransition(task.Status, newStatus))
            {
                error = $"Invalid status transition from {task.Status} to {newStatus}.";
                return false;
            }

            var oldValue = task.Status.ToString();
            task.Status = newStatus;
            task.UpdatedAt = DateTime.UtcNow;

            AddHistory(task.Id, changedByUserId, "StatusChange", oldValue, newStatus.ToString());
            return true;
        }
        private static bool IsValidTransition(TaskStatusModel current, TaskStatusModel target)
        {
            return (current == TaskStatusModel.ToDo && target == TaskStatusModel.InProgress)
                || (current == TaskStatusModel.InProgress && target == TaskStatusModel.Done)
                || current == target;
        }

        // ✅ Assigner / Désassigner
        public static bool AssignTask(int taskId, int? assignedToUserId, int changedByUserId, out string? error)
        {
            error = null;
            var task = Tasks.FirstOrDefault(t => t.Id == taskId);
            if (task == null)
            {
                error = "Task not found.";
                return false;
            }

            var oldValue = task.AssignedToUserId?.ToString() ?? "Unassigned";
            var newValue = assignedToUserId?.ToString() ?? "Unassigned";

            task.AssignedToUserId = assignedToUserId;
            task.UpdatedAt = DateTime.UtcNow;

            AddHistory(task.Id, changedByUserId, "AssignmentChange", oldValue, newValue);
            return true;
        }

        // ✅ Ajouter historique
        public static void AddHistory(int taskId, int changedByUserId, string changeType, string? oldValue, string? newValue)
        {
            var history = new TaskHistory
            {
                Id = _nextHistoryId++,
                TaskId = taskId,
                ChangedByUserId = changedByUserId,
                ChangeType = changeType,
                OldValue = oldValue,
                NewValue = newValue,
                ChangeDate = DateTime.UtcNow
            };
            TaskHistories.Add(history);
        }

        // ✅ Récupérer historique d'une tâche
        public static List<TaskHistory> GetHistoryForTask(int taskId)
        {
            return TaskHistories.Where(h => h.TaskId == taskId).ToList();
        }
    }
}
